<?php

function create_connection(){
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "gameforge";
    
    return new mysqli($host,$username,$password,$database);

}
