<?php
// Database configuration
$host = 'localhost';
$db   = 'gameforge';
$user = 'root';
$pass = ''; 

// Create a connection
$conn = new mysqli($host, $user, $pass, $db);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Fetch user favorite games
$userId = $_SESSION['user_id'];
$sql = "SELECT g.title, g.description, g.genre FROM games g
        JOIN user_preferences up ON g.game_id = up.game_id
        WHERE up.user_id = ? AND up.is_favorite = TRUE";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Favorites - Gameforge</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Your Favorite Games</h2>
<table>
    <tr>
        <th>Title</th>
        <th>Description</th>
        <th>Genre</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td><?php echo htmlspecialchars($row['description']); ?></td>
            <td><?php echo htmlspecialchars($row['genre']); ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<a href="index.php">Back to Home</a>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>