<?php 
include 'views/header.php'; 

// Sample user profile data (replace with dynamic data as needed)
$username = "Gamer123"; 
$avatar = "path_to_avatar_image.jpg"; // Replace with avatar image path
$bio = "Gaming enthusiast. Love strategizing and conquering!";
$gamesPlayed = 150; 
$recentGames = ["Call of Duty", "Mobile Legends", "Clash of Clans"]; 

// Ensure to check if the navbar.php exists before including it
if (file_exists('components/navbar.php')) {
    include 'components/navbar.php'; 
} else {
    echo "<h2>Navbar not found!</h2>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">
    <title><?php echo htmlspecialchars($username); ?>'s Profile</title>
</head>
<body>
<div class="container my-5">
    <h1 class="text-center"><?php echo htmlspecialchars($username); ?>'s Profile</h1>

    <div class="text-center">
        <img src="<?php echo htmlspecialchars($avatar); ?>" alt="Avatar" class="rounded-circle" width="150">
    </div>

    <div class="text-center my-4">
        <h3>Bio</h3>
        <p><?php echo htmlspecialchars($bio); ?></p>
    </div>

    <div class="text-center my-4">
        <h3>Game Statistics</h3>
        <p>Games Played: <?php echo htmlspecialchars($gamesPlayed); ?></p>
    </div>

    <div class="my-4">
        <h3>Recent Games</h3>
        <ul class="list-group">
            <?php foreach ($recentGames as $game): ?>
                <li class="list-group-item"><?php echo htmlspecialchars($game); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<footer class="bg-dark text-white text-center py-4">
    <p>&copy; 2025 Gameforge. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
</html>