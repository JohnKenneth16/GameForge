<?php
$games = [
    ["title" => "CALL OF DUTY", "img" => "codm.webp", "url" => "https://play.google.com/store/apps/details?id=com.activision.callofduty.shooter"],
    ["title" => "MOBILE LEGENDS: BANG BANG", "img" => "MLBB2.webp", "url" => "https://play.google.com/store/apps/details?id=com.mobile.legends"],
    ["title" => "CLASH OF CLANS", "img" => "coc2.png", "url" => "https://play.google.com/store/apps/details?id=com.supercell.clashofclans"],
    ["title" => "PUBG MOBILE", "img" => "pubg.webp", "url" => "https://play.google.com/store/apps/details?id=com.tencent.ig"],
    ["title" => "FREE FIRE", "img" => "freefire.jpg", "url" => "https://play.google.com/store/apps/details?id=com.dts.freefireth"],
   
];

$query = strtolower($_GET['query'] ?? '');
$results = [];

foreach ($games as $game) {
    if (strpos(strtolower($game['title']), $query) !== false) {
        $results[] = $game;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Search Results</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'components/navbar.php'; ?>

<div class="container my-5">
    <h2 class="text-center">Search Results for "<?= htmlspecialchars($query) ?>"</h2>
    <div class="row">
        <?php if (empty($results)): ?>
            <p class="text-center">No games found.</p>
        <?php else: ?>
            <?php foreach ($results as $game): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <img src="<?= $game['img'] ?>" class="card-img-top" alt="<?= $game['title'] ?>">
                        <div class="card-body text-center">
                            <h5 class="card-title"><?= $game['title'] ?></h5>
                            <a href="<?= $game['url'] ?>" class="btn btn-primary" target="_blank">Play Now</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

</body>
</html>