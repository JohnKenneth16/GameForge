<?php
include 'views/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hot Games</title>
    <!-- Link to Bootstrap if you're using it -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Link to your custom style -->
    <link rel="stylesheet" href="style.css">


<div class="container my-5">
        <h2 class="text-center">HOT GAMES</h2>
        
        <div class="row"> 
            
    <div class="col-md-4">
        <div class="card">
            <img src="freefire.jpg" class="card-img-top" alt="Game 4">
            <div class="card-body">
                <h5 class="card-title">FREE FIRE</h5>
                  <p class="card-text"></p>           
                <a href="https://play.google.com/store/apps/details?id=com.dts.freefireth" class="btn btn-primary" target="_blank">Play Now</a>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <img src="pubg.webp" class="card-img-top" alt="Game 5">
            <div class="card-body">
                <h5 class="card-title">PUBG MOBILE</h5>
                 <p class="card-text"></p>
                <a href="https://play.google.com/store/apps/details?id=com.tencent.ig" class="btn btn-primary" target="_blank">Play Now</a>
            </div>
        </div>
    </div>
</div>
<div class="col-md-4">
        <div class="card">
            <img src="assasin.avif" class="card-img-top" alt="Game 6">
            <div class="card-body">
                <h5 class="card-title">ASSASINS CREED</h5>
                 <p class="card-text"></p>
                <a href="https://play.google.com/store/apps/details?id=com.ubisoft.accovenant" class="btn btn-primary" target="_blank">Play Now</a>
            </div>
        </div>
    </div>
</div>
<div class="col-md-4">
        <div class="card">
            <img src="efoot.webp" class="card-img-top" alt="Game 7">
            <div class="card-body">
                <h5 class="card-title">EFOOTBALL</h5>
                 <p class="card-text"></p>
                <a href="https://play.google.com/store/apps/details?id=jp.konami.pesam" class="btn btn-primary" target="_blank">Play Now</a>
            </div>
        </div>
    </div>
</div>
<div class="col-md-4">
        <div class="card">
            <img src="among us.jpg" class="card-img-top" alt="Game 8">
            <div class="card-body">
                <h5 class="card-title">AMONG US</h5>
                 <p class="card-text"></p>
                <a href="https://play.google.com/store/apps/details?id=com.innersloth.spacemafia" class="btn btn-primary" target="_blank">Play Now</a>
            </div>
        </div>
    </div>
</div>
<div class="col-md-4">
        <div class="card">
            <img src="roblox.webp" class="card-img-top" alt="Game 9">
            <div class="card-body">
                <h5 class="card-title">ROBLOX</h5>
                 <p class="card-text"></p>
                <a href="https://play.google.com/store/apps/details?id=com.roblox.client" class="btn btn-primary" target="_blank">Play Now</a>
            </div>
        </div>
    </div>
</div>

   
<?php
include 'views/footer.php';
?>
</head>
<body>