
        <?php
        include 'views/header.php';
        
        echo "Home";
        
        include 'views/footer.php';
        ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">
    <title>Gaming Studio</title>
</head>
<body>
        <?php include 'components/navbar.php'; ?>
    <?php
$games = [
    ["title" => "CALL OF DUTY", "img" => "codm.webp", "url" => "https://play.google.com/store/apps/details?id=com.activision.callofduty.shooter"],
    ["title" => "MOBILE LEGENDS: BANG BANG", "img" => "MLBB2.webp", "url" => "https://play.google.com/store/apps/details?id=com.mobile.legends"],
    ["title" => "CLASH OF CLANS", "img" => "coc2.png", "url" => "https://play.google.com/store/apps/details?id=com.supercell.clashofclans"],
    ["title" => "FREE FIRE", "img" => "freefire.jpg", "url" => "https://play.google.com/store/apps/details?id=com.dts.freefireth"],
    ["title" => "PUBG MOBILE", "img" => "pubg.webp", "url" => "https://play.google.com/store/apps/details?id=com.tencent.ig"]
];

$search_query = strtolower($_GET['query'] ?? '');
$search_results = [];

if (!empty($search_query)) {
    foreach ($games as $game) {
        if (strpos(strtolower($game['title']), $search_query) !== false) {
            $search_results[] = $game;
        }
    }
}
?>

    <div class="jumbotron text-center bg-dark text-white">

    
        <h1 class="display-3">Welcome to GameForge Studios!</h1>
        <p class="lead">Creating immersive worlds and unforgettable experiences.</p>
    </div>

    <div class="container my-5">
        <h2 class="text-center">FEATURES GAMES</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <img src="codm.webp" class="card-img-top" alt="Game 1">
                    <div class="card-body">
                        <h5 class="card-title">CALL OF DUTY</h5></p>
                        <a href="https://play.google.com/store/apps/details?id=com.activision.callofduty.shooter" class="btn btn-primary" target="_blank">Play Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">  
                <div class="card">
                    <img src="MLBB2.webp" class="card-img-top" alt="Game 2">
                    <div class="card-body">
                        <h5 class="card-title">MOBILE LEGENDS: BANG BANG</h5>
                        <p class="card-text"> </p>
                        <a href="https://play.google.com/store/apps/details?id=com.mobile.legends" class="btn btn-primary" target="_blank">Play Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="coc2.png" class="card-img-top" alt="Game 3">
                    <div class="card-body">
                        <h5 class="card-title">CLASH OF CLANS</h5>
                        <p class="card-text"></p>
                        <a href="https://play.google.com/store/apps/details?id=com.supercell.clashofclans" class="btn btn-primary" target="_blank">Play Now</a>
                        
                        
                    </div>
                </div>
            </div>
         
<div class="text-center mt-4"> 
    <a href="see_more.php" class="btn btn-primary" target="_blank">See more</a> 
</div> 



</div>
            
   
    
    <footer class="bg-dark text-white text-center py-4">
        <br>
        <br>
        
        <p>&copy; 2025 Gameforge. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>


