<?php 
// Database configuration
$host = 'localhost'; 
$db = 'gameforge'; 
$user = 'root'; // Database username 
$pass = ''; // Database password 

// Create a connection 
$conn = new mysqli($host, $user, $pass, $db); 

// Check the connection 
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
} 


session_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    $username = $_POST['username']; 
    $email = $_POST['email']; 
    $password = $_POST['password']; 
    $password_hash = password_hash($password, PASSWORD_BCRYPT); 

    $sql = "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)"; 
    $stmt = $conn->prepare($sql); 
    if ($stmt) {
        $stmt->bind_param("sss", $username, $email, $password_hash); 
        if ($stmt->execute()) { 
            $_SESSION['username'] = $username; 
            header("Location: index.php"); 
            exit; 
        } else { 
            $error = "Username or email already exists."; 
        } 
        $stmt->close(); 
    } else {
        $error = "Database statement preparation failed.";
    }
}

?>  

    <?php
include 'views/header.php';
?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <?php include 'components/navbar.php'; ?> 
    
    <div class="container mt-5">
        <h1>Registration</h1>
        <form action="process_registration.php" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="example@gmail.com" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Register</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
<?php
include 'views/footer.php';
?> 
