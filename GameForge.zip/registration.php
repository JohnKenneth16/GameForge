<?php
include 'views/header.php';
?>
<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <form id="registrationform" action="models/register_user.php" method="POST">
        <label for="uname">Username</label>
        <input type="text" name="uname" id="uname" placeholder="Username" required>
        
        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Email" required>
        
        <label for="fname">First name</label>
        <input type="text" name="fname" id="fname" placeholder="First name" required>
        
        <label for="lname">Last name</label>
        <input type="text" name="lname" id="lname" placeholder="Last name" required>
        
        <div id="cbgender">
            <label for="gender">Gender</label>
            <select name="gender" id="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
        </div> 
        
        <label for="bdate">Birthdate</label>
        <input type="date" name="bdate" id="bdate" required>
        
        <label for="pass">Password</label>
        <input type="password" name="pass" id="pass" placeholder="Password" required>
        
        <label for="conpass">Confirm Password</label>
        <input type="password" name="conpass" id="conpass" placeholder="Confirm Password" required>
        
        <input type="checkbox" name="signedin" id="signedin" value="signed">
        <label for="signedin">Agree: <a href="">End-user License</a></label>
        
        <input type="submit" value="Register"> 
    </form>
    
<?php
include 'views/footer.php';
?>
</body>
</html>