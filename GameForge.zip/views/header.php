<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Gameforge</title>
        <link href="./res/mystyle.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="navbar">
            <a href="./index.php">Home</a>
            <a href="./about.php">About</a>
            <a href="./profile.php">Profile</a>
            <a href="./login.php">Login</a>
            <a href="./registration.php">Register</a>
           
        </div>  
